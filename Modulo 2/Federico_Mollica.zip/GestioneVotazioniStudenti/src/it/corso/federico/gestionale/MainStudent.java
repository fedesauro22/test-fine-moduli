package it.corso.federico.gestionale;

import java.util.Scanner;

/**
 * @author Federico Mollica
 * @version 1.0
 * Main class for testing the StudentGrades class
 */
public class MainStudent {

	public static void main(String[] args) {
		
		StudentGrades studenti = new StudentGrades();
		
		//Aggiungo studenti manualmente
		studenti.addGrade("Federico", 25);
		studenti.addGrade("Lorenzo", 30);
		studenti.addGrade("Carlo", 22);
		//Se decommentata la riga sottostante il voto di Carlo verra' sovrascritto da 22 ad 11
		//studenti.addGrade("Carlo", 11);
		System.out.println("-------Stampo gli studenti inseriti dal sistema-------");
		studenti.printGrades();
		System.out.println("--------------");
		Scanner t = new Scanner(System.in);
		//faccio l'inserimento degli studenti tramite input in modo tale da far vedere l'utilizzo dello Scanner e del try-catch-finally visti durante la spiegazione del modulo
		try {
			System.out.println("Scrivi il numero di studenti da inserire: ");
			int numStud = t.nextInt();
			t.nextLine();
			
			for(int i = 0; i < numStud; i++) {
				System.out.println("Inserisci nome dello studente:");
				String nome  = t.nextLine();
				
				System.out.println("Inserisci il voto di " + nome + ": ");
				int voto = t.nextInt();
				t.nextLine();
				
				studenti.addGrade(nome, voto);
			}
		} catch (Exception e) {
			//Non stampo lo stackTrace per non esporre le chiamate ai metodi che hanno portato all'Exception, ma mi limito a stampare un messaggio di errore
			System.out.println("Errore nell'acquisizione dello scanner");
		} finally {
			//Stampo comunque gli studenti inseriti fino al momento dell'Exception e chiudo lo scanner in modo tale da rilasciare la risorsa
			System.out.println("-------Stampo gli studenti fino ad adesso-------");
			studenti.printGrades();
			t.close();
		}
		
		System.out.println("-------Ricerca studente di nome Carlo-------");
		//Provo ad acquisire il voto dello studente "Carlo"
		int gCarlo = studenti.getGrade("Carlo");
		if(gCarlo != -1) {
			System.out.println("Studente: Carlo, Voto: " + gCarlo);
		}
		else {
			System.out.println("Studente non presente!");
		}
	}

}
