/**
 * 
 */
package it.corso.federico.gestionale;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Federico Mollica
 * @version 1.0
 * Class for manage the Student grades
 */
public class StudentGrades {
	Map<String, Integer> students;

	/**
	 * Default constructor, instance the HashMap
	 */
	public StudentGrades() {
		this.students = new HashMap<>();
	}
	
	/**
	 * @param students an existing Map with String key and Integer value
	 */
	public StudentGrades(Map<String, Integer> students) {
		this.students = students;
	}
	
	/**
	 * Add the grade of the input given student
	 * @param studentName the name of the student
	 * @param grade the grade of the student
	 */
	public void addGrade(String studentName, int grade) {
		if(studentName != null && studentName != "") {
			this.students.put(studentName, grade);
			System.out.println("Inserimento riuscito");
		}
		else {
			System.out.println("Inserimento non riuscito");
		}
	}
	
	/**
	 * Get the grade of the input given student name
	 * @param studentName the name of the student
	 * @return an int representing the student's grade if it exist, if not, return -1
	 */
	public int getGrade(String studentName) {
		if(this.students.get(studentName) != null) {
			return this.students.get(studentName);
		}
		return -1;
	}
	
	/**
	 * Prints all the students names and their grades
	 */
	public void printGrades() {
		students.forEach((key, value) -> {
			if(key != null && key != "") {
				System.out.println("Studente: " + key + ", Voto: " + value);
			}
		});
	}
}
