package it.corso.federico;

/**
 * @author Federico Mollica
 */
public class Main {

	public static void main(String[] args) {
		ConnectionUtility db = new ConnectionUtility("127.0.0.1");
		db.initDB("federico_jdbc");
		
		db.insertUtente(1, "Mario", "Rossi");
		db.insertUtente(2, "Andrea", "Verdi");
		db.insertUtente(3, "Massimo", "Bianchi");
		db.insertUtente(4, "Sara", "Vallieri");
		db.insertUtente(5, "Marco", "Graviglia");
		db.insertUtente(6, "Marzia", "Esposito");
		
		db.insertLibro(1, "transistor", "coppelli");
		db.insertLibro(2, "compilatore", "ranieri");
		db.insertLibro(3, "diodi", "stortoni");
		db.insertLibro(4, "algoritmi", "sedge");
		db.insertLibro(5, "pascal", "wirth");
		
		db.insertPrestito(1, "2023-12-04", "2024-01-12", 4, 2);
		db.insertPrestito(2, "2024-11-02", "2024-12-12", 4, 4);
		db.insertPrestito(4, "2023-12-04", null, 4, 1);
		db.insertPrestito(5, "2024-11-02", null, 4, 3);
		db.insertPrestito(3, "2024-01-15", "2024-02-25", 2, 3);
		db.insertPrestito(6, "2024-03-20", "2024-04-15", 5, 5);
		db.insertPrestito(7, "2024-02-10", "2024-03-05", 1, 1);
		db.insertPrestito(8, "2024-05-01", "2024-05-20", 3, 2);
		db.insertPrestito(9, "2024-06-10", null, 6, 4);
		db.insertPrestito(10, "2024-08-15", "2024-09-10", 2, 5);
		
		
		db.query1(4);
		db.query2();
		db.query3();
		db.query4(4, "2023-01-01", "2024-12-12");
		db.query6();
	}

}
