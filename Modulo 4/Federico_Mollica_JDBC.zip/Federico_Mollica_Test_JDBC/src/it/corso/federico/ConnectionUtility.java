package it.corso.federico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.MysqlDataSource;

/**
 * @author Federico Mollica
 */
public class ConnectionUtility {
	private Connection con;
	
	public ConnectionUtility(String host) {
		try {
			startConnection(host);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void initDB(String dbName) {
		try {
			createDatabase(dbName);
			createTableUtente();
			createTableLibro();
			createTablePrestito();
		} catch (SQLException e) {
			System.out.println("Errore nell'inizializzazione del db!");
		}
		
	}
	
	private Connection startConnection(String host) throws SQLException {
		if(con == null) {
			MysqlDataSource ds= new MysqlDataSource();
			ds.setServerName(host);
			ds.setPortNumber(3306);
			ds.setUser("root");
			ds.setPassword("admin");
			
			con = ds.getConnection();
		}
		return con;
	}
	
	private void createDatabase(String dbName) throws SQLException {
		String sql = "CREATE DATABASE IF NOT EXISTS " + dbName;
		Statement st = con.createStatement();
		st.execute(sql);
		st.execute("USE " + dbName);
		st.close();
	}
	
	private void createTableUtente() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS Utente ("
				+ "id INT PRIMARY KEY NOT NULL,"
				+ "cognome VARCHAR(255), "
				+ "nome VARCHAR(255)"
				+ ")";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.executeUpdate();
		ps.close();
	}
	
	private void createTableLibro() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS Libro ("
				+ "id INT PRIMARY KEY NOT NULL,"
				+ "titolo VARCHAR(255), "
				+ "autore VARCHAR(255) "
				+ ")";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.executeUpdate();
		ps.close();
	}
	
	private void createTablePrestito() throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS Prestito ("
				+ "id INT PRIMARY KEY NOT NULL,"
				+ "inizio DATE, "
				+ "fine DATE,"
				+ "id_U INT NOT NULL,"
				+ "id_L INT NOT NULL,"
				+ "FOREIGN KEY (id_U) REFERENCES Utente (id),"
				+ "FOREIGN KEY (id_L) REFERENCES Libro (id)"
				+ ")";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.executeUpdate();
		ps.close();
	}
	
	public void insertUtente(int id, String nome, String cognome) {
		String sql = "INSERT INTO Utente (id, nome, cognome) VALUES (?, ?, ?)";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ps.setInt(1, id);
			ps.setString(2, nome);
			ps.setString(3, cognome);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Errore durante l'inserimento dell'utente");
		}
	}
	
	public void insertLibro(int id, String titolo, String autore) {
		String sql = "INSERT INTO Libro (id, titolo, autore) VALUES (?, ?, ?)";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ps.setInt(1, id);
			ps.setString(2, titolo);
			ps.setString(3, autore);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Errore durante l'inserimento del libro");
		}
	}
	
	public void insertPrestito(int id, String inizio, String fine, int id_U, int id_L) {
		String sql = "INSERT INTO Prestito (id, inizio, fine, id_U, id_L) VALUES (?, ?, ?, ?, ?)";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ps.setInt(1, id);
			ps.setString(2, inizio);
			ps.setString(3, fine);
			ps.setInt(4, id_U);
			ps.setInt(5, id_L);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Errore durante l'inserimento del prestito");
		}
	}
	
	/**
	 * Query 1)
	 * */
	public void query1(int id) {
		String sql = "SELECT l.autore, l.titolo, p.inizio, p.fine FROM Prestito p INNER JOIN Libro l ON p.id_L = l.id INNER JOIN Utente u ON u.id = p.id_U WHERE u.id = ? ORDER BY p.inizio;";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			System.out.println("--------LISTA DEI LIBRI PRESTATI ALL'UTENTE CON ID " + id + " IN ORDINE CRONOLOGICO--------");
			while(rs.next()) {
				System.out.println("Autore: " + rs.getString("autore"));
				System.out.println("Titolo: " + rs.getString("titolo"));
				System.out.println("Inizio prestito: " + rs.getDate("inizio"));
				System.out.println("Fine prestito: " + rs.getDate("fine"));
				System.out.println("--------------------------");
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println("Errore durante il recupero dei dati");
		}
	}
	
	/**
	 * Query 2)
	 * */
	public void query2() {
		String sql = "SELECT u.nome, u.cognome, COUNT(u.id) AS prestiti FROM Utente u INNER JOIN Prestito p ON p.id_U = u.id GROUP BY u.id ORDER BY prestiti DESC LIMIT 3;";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ResultSet rs = ps.executeQuery();
			System.out.println("--------LISTA DEI TOP 3 LETTORI--------");
			while(rs.next()) {
				System.out.println("Nome: " + rs.getString("nome"));
				System.out.println("Cognome: " + rs.getString("cognome"));
				System.out.println("Libri prestati: " + rs.getInt("prestiti"));
				System.out.println("--------------------------");
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println("Errore durante il recupero dei dati");
		}
	}
	
	/**
	 * Query 3)
	 * */
	public void query3() {
		String sql = "SELECT u.nome, u.cognome, l.titolo FROM Prestito p INNER JOIN Utente u ON u.id = p.id_U INNER JOIN Libro l ON l.id = p.id_L WHERE p.fine IS NULL;";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ResultSet rs = ps.executeQuery();
			System.out.println("--------LISTA DEGLI UTENTI CHE NON HANNO ANCORA TORNATO I LIBRI--------");
			while(rs.next()) {
				System.out.println("Nome: " + rs.getString("nome"));
				System.out.println("Cognome: " + rs.getString("cognome"));
				System.out.println("Titolo: " + rs.getString("titolo"));
				System.out.println("--------------------------");
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println("Errore durante il recupero dei dati");
		}
	}
	
	/**
	 * Query 4)
	 * */
	public void query4(int id_U, String inizio, String fine) {
		String sql = "SELECT l.titolo FROM Prestito p INNER JOIN Utente u ON u.id = p.id_U INNER JOIN Libro l ON l.id = p.id_L WHERE p.inizio BETWEEN ? AND ? AND u.id = ?;";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ps.setString(1, inizio);
			ps.setString(2, fine);
			ps.setInt(3, id_U);
			ResultSet rs = ps.executeQuery();
			System.out.println("--------LISTA DEI LIBRI CHIESTI IN PRESTITO DALL'UTENTE "+	id_U + " NEL PERIODO "+ inizio + " " + fine +"--------");
			while(rs.next()) {
				System.out.println(rs.getString("titolo"));
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println("Errore durante il recupero dei dati");
		}
	}
	
	/**
	 * Query 6)
	 * */
	public void query6() {
		String sql = "SELECT l.titolo, u.nome, u.cognome, p.* FROM Prestito p INNER JOIN Utente u ON p.id_U = u.id INNER JOIN Libro l ON l.id = p.id_L WHERE (TIMESTAMPDIFF(DAY, p.inizio, p.fine) > 15 AND p.fine IS NULL) OR TIMESTAMPDIFF(DAY, p.inizio, CURDATE()) > 15;";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ResultSet rs = ps.executeQuery();
			System.out.println("--------LISTA DEI PRESTITI CON DURATA SUPERIORE AI 15 GIORNI--------");
			while(rs.next()) {
				System.out.println("Id Prestito: " + rs.getInt("id"));
				System.out.println("Data Inizio: " + rs.getDate("inizio"));
				if(rs.getDate("fine") != null) {
					System.out.println("Data Fine: " + rs.getDate("fine"));
				}
				else {
					System.out.println("Data Fine: Ancora in possesso");
				}
				System.out.println("Cliente: " + rs.getString("nome") + " " + rs.getString("cognome"));
				System.out.println("Libro: " + rs.getString("titolo"));
				System.out.println("--------------------------");
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println("Errore durante il recupero dei dati");
		}
	}
}
