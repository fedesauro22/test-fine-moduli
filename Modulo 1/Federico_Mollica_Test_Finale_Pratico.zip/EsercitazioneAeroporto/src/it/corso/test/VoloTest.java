package it.corso.test;
/**
 * @author Federico Mollica
 * @version 1.0
*/
public class VoloTest {

	public static void main(String[] args) {
		Aereoporto a1 = new Aereoporto("Galilei", "Pisa", "PSA");
        Aereoporto a2 = new Aereoporto("Fiumicino", "Roma", "FCO");
        Aereoporto a3 = new Aereoporto("Fontanarossa", "Catania", "CTA");
        Aereoporto a4 = new Aereoporto("Marco Polo", "Venezia", "VCE");
        Volo v1 = new Volo("AZ124", a1.getNome(), a2.getNome(), "Airbus300", 2);
        
        //System.out.println(v1.getVolo());
        //VoloNonDiretto vnd1 = new VoloNonDiretto("AZ124", a1.getNome(), a2.getNome(), "Airbus300", 2, 2);
        VoloNonDiretto vnd1 = new VoloNonDiretto(v1, 2);
        
        vnd1.addScalo(a3);
        vnd1.addScalo(a4);
        
        Passeggero p1 = new Passeggero("Mario Rossi", "Italiana", v1.getSigla(), "16F", "vegetariano");
        Passeggero p2 = new Passeggero("Luca Verdi", "Inglese",  v1.getSigla(), "20A", "pesce");
        p1.setPosto("22B");
        
        vnd1.addPasseggero(p2);
        vnd1.addPasseggero(p1);
        
        System.out.println("Lista passeggeri per il "+ vnd1.getVolo() + ":\n" + vnd1.getPasseggeri());
        System.out.println("Lista posti passeggeri con pasto vegetariano per il "+ vnd1.getVolo() + ":\n" + vnd1.getPastoVegetariano());

	}
	
}
