package it.corso.test;
/**
 * @author Federico Mollica
 * @version 1.0
*/
public class Passeggero {
	private String nome;
	private String nazionalita;
	private String siglaVolo;
	private String posto;
	private String pasto;
	public Passeggero(String nome, String nazionalita, String siglaVolo, String posto, String pasto) {
		super();
		this.nome = nome;
		this.nazionalita = nazionalita;
		this.siglaVolo = siglaVolo;
		this.posto = posto;
		this.pasto = pasto;
	}
	public String getNome() {
		return nome;
	}
	public String getNazionalita() {
		return nazionalita;
	}
	public String getSiglaVolo() {
		return siglaVolo;
	}
	public String getPosto() {
		return posto;
	}
	public void setPosto(String posto) {
		this.posto = posto;
	}
	public String getPasto() {
		return pasto;
	}
	
}
