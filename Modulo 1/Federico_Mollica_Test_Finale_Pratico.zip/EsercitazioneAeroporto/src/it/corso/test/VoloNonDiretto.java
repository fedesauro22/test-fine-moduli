package it.corso.test;
/**
 * @author Federico Mollica
 * @version 1.0
*/
public class VoloNonDiretto extends Volo{
	private int maxScali;
	private Aereoporto scali[];
	private int currScali;
	public VoloNonDiretto(Volo v, int maxScali) {
		super(v.getSigla(), v.getPartenza(), v.getDestinazione(), v.getAeromobile(), v.getMaxPasseggeri());
		this.maxScali = maxScali;
		this.scali = new Aereoporto[maxScali];
		this.currScali = 0;
	}
	public VoloNonDiretto(String sigla, String partenza, String destinazione, String aeromobile, int maxPasseggeri, int maxScali) {
		super(sigla, partenza, destinazione, aeromobile, maxPasseggeri);
		this.maxScali = maxScali;
		this.scali = new Aereoporto[maxScali];
		this.currScali = 0;
	}
	public int getMaxScali() {
		return maxScali;
	}
	public Aereoporto[] getScali() {
		return scali;
	}
	public int getCurrScali() {
		return currScali;
	}
	
	public void addScalo(Aereoporto a) {
		if(currScali < maxScali) {
			scali[currScali++] = a;
			System.out.println("Scalo aggiunto con successo!");
		}
		else {
			System.out.println("Numero di scali massimi raggiunto!");
		}
	}
	
	@Override
	public String getVolo() {
		String res = super.getVolo();
		if (currScali > 0) {
			res += " via ";
			for (int i = 0; i < currScali; i++) {
				if (i < currScali - 1) {
					res += (scali[i].getCitta() + " " + scali[i].getNome() + " - ");
				} else {
					res += (scali[i].getCitta() + " " + scali[i].getNome());
				}

			} 
		}
		return res;
	}
	
}
