package it.corso.test;
/**
 * @author Federico Mollica
 * @version 1.0
*/
public class Volo {
	private String sigla;
	private String partenza;
	private String destinazione;
	private String aeromobile;
	private Passeggero[] passeggeri;
	public int currPasseggeri;
	public int maxPasseggeri;
	public Volo(String sigla, String partenza, String destinazione, String aeromobile, int maxPasseggeri) {
		super();
		this.sigla = sigla;
		this.partenza = partenza;
		this.destinazione = destinazione;
		this.aeromobile = aeromobile;
		this.maxPasseggeri = maxPasseggeri;
		this.passeggeri = new Passeggero[maxPasseggeri];
		this.currPasseggeri = 0;
	}
	public String getSigla() {
		return sigla;
	}
	public String getPartenza() {
		return partenza;
	}
	public String getDestinazione() {
		return destinazione;
	}
	public String getAeromobile() {
		return aeromobile;
	}
	public int getCurrPasseggeri() {
		return currPasseggeri;
	}
	public int getMaxPasseggeri() {
		return maxPasseggeri;
	}
	public void addPasseggero(Passeggero p) {
		if(currPasseggeri < maxPasseggeri) {
			passeggeri[currPasseggeri++] = p;
			System.out.println("Passeggero aggiunto con successo!");
		}
		else {
			System.out.println("Capienza massima raggiunta");
		}
	}
	public String getVolo() {
		return "Volo " + this.sigla + " " + this.partenza + " - " + this.destinazione;
	}
	public String getPasseggeri() {
		String res = "";
		for(int i = 0; i < currPasseggeri; i++) {
			res += (passeggeri[i].getNome() + '\n');
		}
		if(res.equals("")) {
			res = "Nessun passeggero registrato";
		}
		return res;
	}
	public String getPastoVegetariano() {
		String res = "";
		for(int i = 0; i < currPasseggeri; i++) {
			if((passeggeri[i].getPasto()).equals("vegetariano")) {
				res += (passeggeri[i].getPosto() + '\n');
			}
			
		}
		if(res.equals("")) {
			res = "Nessun passeggero con pasto vegetariano";
		}
		return res;
	}
	
}
